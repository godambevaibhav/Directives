import {OnInit,ElementRef,Directive,Renderer2,HostListener,Input} from '@angular/core';

@Directive({
    selector : '[ipaddress]'
})
export class IpPattern implements OnInit {

    @Input()
     ItemIpAddress : string;

    constructor(private elementRef:ElementRef, private renderer:Renderer2) {

     }

     @HostListener('keyup')
        onkeyup(eventData:Event){
            console.log("Directive ," + this.ItemIpAddress);



           // this.renderer.setStyle( this.elementRef.nativeElement,'background-color','red');
        }

      @HostListener('mouseleave')
        onMouseLeave(eventData:Event){
            //this.renderer.setStyle( this.elementRef.nativeElement,'background-color','transparent');
        }

    ngOnInit() {
      //this.elementRef.nativeElement.style.backgroundColor = 'yellow';
    }

}