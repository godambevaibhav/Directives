import {OnInit,ElementRef,Directive,Renderer2,HostListener,Input} from '@angular/core';

@Directive({
    selector : '[bkcolor]'
})
export class FirstBasic implements OnInit {

    @Input()
     ItemColor : string;

    constructor(private elementRef:ElementRef, private renderer:Renderer2) {

     }

     @HostListener('mouseenter')
        onMouseEnter(eventData:Event){
            console.log("Directive ," + this.ItemColor);

            if(this.ItemColor === undefined){
                this.ItemColor = 'grey';
            }
            
            this.renderer.setStyle( this.elementRef.nativeElement,'background-color',this.ItemColor);
        }

      @HostListener('mouseleave')
        onMouseLeave(eventData:Event){
            this.renderer.setStyle( this.elementRef.nativeElement,'background-color','transparent');
        }

    ngOnInit() {
      this.elementRef.nativeElement.style.backgroundColor = 'yellow';
    }

}