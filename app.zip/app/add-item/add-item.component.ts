import { Component, OnInit, Output, EventEmitter, ViewChild, OnChanges, SimpleChanges, Input} from '@angular/core';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit , OnChanges{

  // Need to add decorator when we passing the value from child to parent component
  // @Output is decorator
  // itemAddedEvent is EventEmitter name of child component
  // Syntax for EventEmitter : 
  // EventEmitter_Name = new new EventEmitter<{ properties that we want to emit }>()
  @Output () 
  itemAddedEvent = new EventEmitter<{ name: string, price: string, desc: string }>()

  @Input ()
  Quantity : number;

  ItemColor : string;
  ItemIpAddress: string;
  

 //Use for reference selector
  @ViewChild('ItemQuantity') ItemQuantity;

 itemName: string;
 itemPrice: string;
 itemDesc: string;

 constructor() {
   //console.log("Constructor call");
  }

  ngOnInit() {
    //console.log("ngOnInit call");
  }

  // onSubmit method is call emit method 
  onSubmit() {
  //console.log(this.ItemColor);

    this.itemAddedEvent.emit({
      name: this.itemName,
      price: this.itemPrice,
      desc: this.itemDesc
    });

    //console.log(this.ItemQuantity); // nativeElement reference 
    //console.log(this.ItemQuantity.nativeElement.value);
  }


  /* This only life cycle hook is accept the parameter */
  ngOnChanges(changes: SimpleChanges){
     //console.log("ngOnChanges call");
     //console.log(this.ItemQuantity.nativeElement.value);
    // console.log(changes);// Get changes object 
    //console.log(changes.Quantity.currentValue,changes.Quantity.previousValue); // chnage the values 
  }

}
