import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { AddItemComponent } from './add-item/add-item.component';
import { ItemCardListComponent } from './item-card-list/item-card-list.component';

// Directive referance added
import { FirstBasic } from './directives/first-basic.directives'; 
import { IpPattern } from './directives/ip-pattern.directives'; 

@NgModule({
  declarations: [
    AppComponent,
    AddItemComponent,
    ItemCardListComponent,
    FirstBasic,
    IpPattern
  ],
  imports: [
    BrowserModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
